# watchlist-search

>Provide HTTP API for searching watchlist's mantras.